<?php
  if(!isset($_GET["id"])) exit();
  
  $id = $_GET["id"];
  include_once "../conexion.php";
  $sentencia = $base_de_datos->query("SELECT * FROM personas WHERE id =".$id);
  $persona = $sentencia->fetch_assoc() ;
?> 
<html lang="es">
<head>
	<meta charset="UTF-8">	
</head>
<body>
	<form method="post" action="guardarDatosEditados.php">
		<!-- Ocultamos el ID para que el usuario  -->
		<input type="hidden" name="id" value="<?php echo $persona["id"]; ?>">

		<label for="nombre_completo">Nombre:</label>
		<br>
		<input value="<?php echo $persona["nombre_completo"]?>" name="nombre_completo" required type="text" id="nombre_completo" placeholder="Escribe tu nombre...">
		<br><br>
		<label for="email">Email:</label>
		<br>
		<input value="<?php echo $persona["email"]; ?>" name="email" required type="text" id="email" placeholder="Escribe tu correo...">
		<br><br>
		<label for="telefono">Email:</label>
		<br>
		<input value="<?php echo $persona["telefono"]; ?>" name="telefono" required type="text" id="telefono" placeholder="Escribe tu telefono...">
		<br><br>
		<label for="contraseña">Email:</label>
		<br>
		<input value="<?php echo $persona["contraseña"]; ?>" name="contraseña" required type="password" id="contraseña" placeholder="Escribe tu contraseña">
		<br><br>

		<br><br><input type="submit" value="Editar Cambios">
	</form>
</body>
</html>