<?php
#isset significa q la variable que se recibe esta vacia, entonces sale 
if (  !isset($_POST["nombre_completo"]) || !isset($_POST["email"]) || !isset($_POST["telefono"]) || !isset($_POST["contraseña"]) ) exit();

include_once "conexion.php";

$nombre_completo    = $_POST["nombre_completo"];
$email   = $_POST["email"];
$telefono     = $_POST["telefono"];
$contraseña   = $_POST["contraseña"];


$sentencia = $base_de_datos->prepare("INSERT INTO tabla_registro(nombre_completo, email, telefono, contraseña) VALUES (?, ?, ?, ?);");
$resultado = $sentencia->execute([$nombre_completo, $email, $telefono, $contraseña ]); # Pasar en el mismo orden de los ?
#execute regresa un booleano. True en caso de que todo vaya bien, falso en caso contrario.
#Con eso podemos evaluar

if ($resultado === TRUE) 
   echo "Insertado correctamente";
else
  echo "Algo salió mal. Por favor verifica que la tabla! ";


?>