document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('contactForm');

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        // Simulando envío de formulario
        // Aquí podrías enviar el formulario mediante AJAX o fetch

        // Mostrar alerta de éxito con SweetAlert
        swal("¡Enviado!", "Tu mensaje ha sido enviado con éxito.", "success");

        // Limpiar el formulario después de enviarlo
        form.reset();
    });
});
